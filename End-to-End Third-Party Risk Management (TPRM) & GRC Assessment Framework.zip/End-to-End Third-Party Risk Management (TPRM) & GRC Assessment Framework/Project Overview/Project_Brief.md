# Project Brief

## Scenario
FinSecure Technologies (fictional) is evaluating CloudNova Solutions (fictional) as a cloud hosting and backup provider for customer and transaction data.

## Analyst role
Simulated TPRM Analyst responsible for coordinating due diligence, evaluating reported controls, documenting gaps and risks, recommending treatment and preparing a management decision brief.

## In scope
- Vendor governance and security assurance
- Identity, access and authentication
- Data protection, retention and deletion
- Subprocessor oversight
- Backup, disaster recovery and business continuity
- Evidence requests, remediation and monitoring

## Out of scope
- Actual vendor audit or penetration test
- Technical validation of CloudNova's environment
- Legal opinion or formal certification
- Real customer data or real supplier records

## Intended audience
Cybersecurity / GRC recruiters, hiring managers and interviewers seeking evidence of structured risk assessment, documentation and communication skills.
