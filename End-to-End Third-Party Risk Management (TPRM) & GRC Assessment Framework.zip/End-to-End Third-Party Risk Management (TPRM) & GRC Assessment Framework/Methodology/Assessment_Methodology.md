# Assessment Methodology

## 1. Preparation
Define the service, data categories, business purpose, assessment boundary, stakeholders and vendor criticality. Confirm whether the service is business-critical and whether sensitive or regulated data is involved.

## 2. Due diligence
Use a structured questionnaire covering governance, security policies, IAM, encryption, vulnerability management, incident response, data handling, subcontractors and resilience. Treat answers as vendor-reported until evidence is obtained and assessed.

## 3. Evidence review
For each control, record:
- evidence requested;
- evidence received / not received;
- date and owner;
- scope and period covered;
- reviewer observations;
- validation status and limitations.

A vendor statement is not equivalent to independent evidence. Do not label a control effective solely because a questionnaire answer is “Yes”.

## 4. Risk assessment
Score each risk using:
**Likelihood (1–5) × Impact (1–5) = Inherent risk score.**

Illustrative bands:
- 1–4 Low
- 5–9 Medium
- 10–16 High
- 17–25 Critical

Consider business impact, data sensitivity, threat exposure, control design, operating evidence and uncertainty. Document rationale rather than relying on a score alone.

## 5. Treatment and residual risk
For each material gap, specify remediation, accountable owner, target date, evidence of closure and onboarding gate. Residual risk should only be accepted by an authorised business / risk owner under the organisation's governance process.

## 6. Onboarding decision logic
- Do not onboard production data while critical safeguards remain unverified.
- Use conditional approval only to permit controlled pre-onboarding activity, not production processing.
- Require contractual protections and operational monitoring.
- Reassess after material service, ownership, location, subprocessor or threat changes.

## 7. Business continuity
Use a Business Impact Analysis to propose MTD, RTO and RPO. These targets must be validated by service and business owners. A backup schedule does not prove recoverability; require restoration tests and recorded outcomes.

## 8. Limitations
This project uses a fictional scenario and illustrative data. No vendor evidence was actually received or independently tested. Scores, findings, controls and recovery targets are portfolio examples, not actual audit conclusions.
