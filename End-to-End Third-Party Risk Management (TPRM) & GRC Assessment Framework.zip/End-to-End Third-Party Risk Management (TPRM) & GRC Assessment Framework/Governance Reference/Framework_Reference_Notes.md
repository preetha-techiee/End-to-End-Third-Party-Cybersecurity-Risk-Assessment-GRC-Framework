# Framework and Reference Notes

The following frameworks and regulatory instruments informed the illustrative control themes in this case study:

- ISO/IEC 27001:2022 — Information security management systems.
- NIST Cybersecurity Framework 2.0 — cybersecurity risk management outcomes.
- ISO 22301:2019 — business continuity management systems.
- GDPR — assess territorial scope and roles before determining applicability.
- Digital Personal Data Protection Act, 2023 and DPDP Rules, 2025 (India) — check phased commencement, applicability and current legal requirements at the time of use.

## Important interpretation notes
- A framework mapping is not a certification or proof of compliance.
- GDPR controller / processor and DPDP Data Fiduciary / Data Processor roles depend on actual processing purposes, means, contracts and applicable law.
- Regulatory commencement and obligations can change; verify current official sources before relying on legal conclusions.
- This portfolio is not legal advice.
